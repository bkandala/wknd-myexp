package com.adobe.aem.guides.wknd.core.pojo.analytics;

public class AdeptData {

	private Page page;
	private Site site;

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}
}
