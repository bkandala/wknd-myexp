package com.adobe.aem.guides.wknd.core.service;

import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.wcm.api.Page;

public interface DatalayerIntf {

	public String getData(Page currentPage, 
			ResourceResolver resourceResolver, SiteConfigurationService service);
}
