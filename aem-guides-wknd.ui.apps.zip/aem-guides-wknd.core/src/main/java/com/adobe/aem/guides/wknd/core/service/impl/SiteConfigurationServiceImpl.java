package com.adobe.aem.guides.wknd.core.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.osgi.service.metatype.annotations.Option;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.wknd.core.pojo.SiteConfig;
import com.adobe.aem.guides.wknd.core.service.SiteConfigurationService;

@Component(immediate = true, service = SiteConfigurationService.class, configurationPid = "com.adobe.aem.guides.wknd.core.service.impl.SiteConfigurationServiceImpl")
@Designate(ocd = SiteConfigurationServiceImpl.Configuration.class, factory = true)
public class SiteConfigurationServiceImpl implements SiteConfigurationService {

	private static final Logger LOG = LoggerFactory.getLogger(SiteConfigurationServiceImpl.class);

	private String micrositeName;

	private String micrositePatttern;

	private String domain;

	private String protocol;

	private String subDomain;

	private Pattern sitePathPattern;

	private String[] regexPatternMatch;

	private boolean enableDataLayer;

	private Map<String, Integer> groupingMap;
	
	private String dataLayerImplClass;

	@Activate
	@Modified
	protected void activate(Configuration config) {
		this.micrositeName = config.microsite_name();

		this.micrositePatttern = config.microsite_pattern();

		this.domain = config.microsite_domain();

		this.protocol = config.protocol();

		this.subDomain = config.microsite_subdomain();

		this.enableDataLayer = config.microsite_enable_datalayer();

		this.regexPatternMatch = config.pattern_matching();
		if (this.micrositePatttern != null) {
			sitePathPattern = Pattern.compile(this.micrositePatttern);
		}

		if (this.regexPatternMatch != null) {
			groupingMap = new HashMap<>();

			for (String mapStr : this.regexPatternMatch) {
				String[] strArr = mapStr.split(":::");

				groupingMap.put(strArr[0].trim(), Integer.parseInt(strArr[1].trim()));
			}
		}
		
		this.dataLayerImplClass = config.microsite_datalayerImpl();

	}

	@ObjectClassDefinition(name = "Generic Configuration for a Microsites -- OSGI", description = "This configuration contains properties related to a single Microsite")
	public @interface Configuration {

		@AttributeDefinition(name = "Microsite name", description = "The Microsite name which serves as the Key.", type = AttributeType.STRING)
		String microsite_name() default "mykp";

		@AttributeDefinition(name = "Microsite domain", description = "The Microsite domain.", type = AttributeType.STRING)
		String microsite_domain() default "kp.org";

		@AttributeDefinition(name = "Microsite subdomain", description = "The Microsite subdomain.", type = AttributeType.STRING)
		String microsite_subdomain() default "kp.microsite-1.org";

		@AttributeDefinition(name = "Microsite Protocol", description = "The Microsite Protocol default to http.", options = {
				@Option(label = "HTTP", value = "http"),
				@Option(label = "HTTPS", value = "https") }, type = AttributeType.STRING)
		String protocol() default "http";

		@AttributeDefinition(name = "Microsite Regex pattern.", description = "The Microsite content path from which the region and language info can be obtained.", type = AttributeType.STRING)
		String microsite_pattern() default "/content/kp/mykp/microsite-1/([^/]+)/([^/]+)/(.*)";

		@AttributeDefinition(name = "Pattern Group Mapping", description = "This is he regex pattern group mapping eg: <<region>>:::<<group index>>", type = AttributeType.STRING)
		String[] pattern_matching() default { "region:::1", "language:::2", "contentPath:::3" };

		@AttributeDefinition(name = "Enable data layer service.", description = "This allows the data layer service to be enabled.", type = AttributeType.BOOLEAN)
		boolean microsite_enable_datalayer() default true;
		
		@AttributeDefinition(name = "DataLayer Class.", description = "The datalayer implemetation class with package.", type = AttributeType.STRING)
		String microsite_datalayerImpl() default "com.adobe.aem.guides.wknd.core.service.impl.DataLayerImpl";

	}

	public boolean checkIfmatchingSite(String path) {
		if (path != null) {
			return this.sitePathPattern.matcher(path).matches();
		}
		return false;
	}

	public SiteConfig getSiteConfiguration(String path) {
		SiteConfig config = new SiteConfig();

		config.setDomain(this.domain);
		config.setSubDomain(this.subDomain);
		config.setName(this.micrositeName);
		config.setProtocol(this.protocol);
		config.setEnableDataService(this.enableDataLayer);

		if (sitePathPattern.matcher(path).matches()) {
			Matcher m = sitePathPattern.matcher(path);

			int count = m.groupCount();
			LOG.info("Group Count :::::::::: " + count);
			if (m.matches()) {
				if (groupingMap.get("language") != null) {
					config.setLanguage(m.group(groupingMap.get("language")));
					LOG.info("Group language:::::::::: " + config.getLanguage());
				}
				if (groupingMap.get("region") != null) {
					config.setRegion(m.group(groupingMap.get("region")));
					LOG.info("Group  region :::::::::: " + config.getRegion());
				}
			}
		}
		return config;
	}

	public String getPathForSection(String fullpath) {
		String validPath = null;
		if (sitePathPattern.matcher(fullpath).matches()) {
			Matcher m = sitePathPattern.matcher(fullpath);
			if (m.matches()) {
				if (groupingMap.get("contentPath") != null) {
					validPath = m.group(groupingMap.get("contentPath"));
					LOG.info("Group validPath:::::::::: " + validPath);
				}

			}
		}
		return validPath;
	}

	public String getProtocol() {
		return protocol;
	}

	public String getMicrositeName() {
		return micrositeName;
	}

	public String getDomain() {
		return domain;
	}

	public boolean isEnableDataLayer() {
		return enableDataLayer;
	}

	public String getDataLayerImplClass() {
		return dataLayerImplClass;
	}

}
