package com.adobe.aem.guides.wknd.core.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.wknd.core.service.SiteConfigurationRegistry;
import com.adobe.aem.guides.wknd.core.service.SiteConfigurationService;

@Component(immediate = true, service = SiteConfigurationRegistry.class)
public class SiteConfigurationRegistryImpl implements SiteConfigurationRegistry {

	private static final Logger LOG = LoggerFactory.getLogger(SiteConfigurationRegistryImpl.class);

	private Map<String, SiteConfigurationService> siteConfigMap = new HashMap<String, SiteConfigurationService>();

	@Reference(name = "siteConfigurationService", cardinality = ReferenceCardinality.MULTIPLE, policy = ReferencePolicy.DYNAMIC)
	protected synchronized void bindSiteConfig(final SiteConfigurationService config) {
		LOG.info("Registering DataLayer Service :::::::::::::::::::: " + config.getMicrositeName());
		this.siteConfigMap.put(config.getMicrositeName(), config);
	}

	protected synchronized void unbindSiteConfig(final SiteConfigurationService config) {
		this.siteConfigMap.remove(config.getMicrositeName());
		LOG.info("UN-Registering Datalayer Service :::::::::::::::::::: " + config.getMicrositeName());
	}

	@Override
	public SiteConfigurationService getMicrositeConfiguration(String siteKey) {

		SiteConfigurationService service = null;
		if (siteKey != null && siteConfigMap.size() > 0) {
			service = siteConfigMap.get(siteKey);
		}
		return service;
	}

	@Override
	public Set<String> getAllMicrositeConfigurationKeys() {
		Set<String> keys = null;
		if (siteConfigMap != null) {
			keys = siteConfigMap.keySet();
		}
		return keys;
	}

	@Override
	public SiteConfigurationService getSiteConfigByMatchingPath(String path) {
		SiteConfigurationService service = null;
		if (path != null) {
			Set<String> keys = getAllMicrositeConfigurationKeys();

			Iterator<String> iter = keys.iterator();

			while (iter.hasNext()) {
				String key = iter.next();
				service = siteConfigMap.get(key);

				if (service.checkIfmatchingSite(path)) {
					break;
				}
			}
		}
		return service;
	}

}
