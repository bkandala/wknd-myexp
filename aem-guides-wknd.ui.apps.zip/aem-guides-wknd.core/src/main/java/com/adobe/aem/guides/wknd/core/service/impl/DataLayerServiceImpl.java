package com.adobe.aem.guides.wknd.core.service.impl;

import org.apache.sling.api.request.RequestPathInfo;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.wknd.core.pojo.SiteConfig;
import com.adobe.aem.guides.wknd.core.pojo.analytics.AdeptData;
import com.adobe.aem.guides.wknd.core.pojo.analytics.Category;
import com.adobe.aem.guides.wknd.core.pojo.analytics.Content;
import com.adobe.aem.guides.wknd.core.pojo.analytics.PageInfo;
import com.adobe.aem.guides.wknd.core.pojo.analytics.Section;
import com.adobe.aem.guides.wknd.core.pojo.analytics.Site;
import com.adobe.aem.guides.wknd.core.service.DataLayerService;
import com.adobe.aem.guides.wknd.core.service.SiteConfigurationRegistry;
import com.adobe.aem.guides.wknd.core.service.SiteConfigurationService;
import com.day.cq.commons.PathInfo;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component(immediate = true, service = DataLayerService.class, configurationPid = "com.adobe.aem.guides.wknd.core.service.impl.DataLayerServiceImpl")
public class DataLayerServiceImpl implements DataLayerService {

	private static final Logger LOG = LoggerFactory.getLogger(DataLayerServiceImpl.class);

	@Reference
	SiteConfigurationRegistry siteService;

	public String getData(Page currentPage, ResourceResolver resourceResolver) {
		String pageData = null;
		try {
			String path = currentPage.getPath();
			LOG.info("CURRENT Page Path ::: " + path);

			final RequestPathInfo mappedPathInfo = new PathInfo(resourceResolver, path);

			String fullPath = mappedPathInfo.getResourcePath();
			LOG.info("CURRENT Page FullPath ::: " + fullPath);

			SiteConfigurationService service = siteService.getSiteConfigByMatchingPath(fullPath);

			if (service != null && service.isEnableDataLayer()) {
				AdeptData data = new AdeptData();

				ValueMap map = currentPage.getProperties();

				PageInfo pgInfo = createPageInfo(currentPage);

				com.adobe.aem.guides.wknd.core.pojo.analytics.Page pg = new com.adobe.aem.guides.wknd.core.pojo.analytics.Page();
				pg.setPageInfo(pgInfo);

				final TagManager tm = (TagManager) resourceResolver.adaptTo(TagManager.class);

				LOG.info("TagManager TagManager ::: " + tm);
				Content cont = getPageContent(tm, map, currentPage);

				pg.setContent(cont);

				Category category = getCategory(tm, map);

				pg.setCategory(category);

				String validPath = service.getPathForSection(fullPath);
				LOG.info("VALID PATH VALUE :: ::: " + validPath);
				Section section = getSection(validPath);
				pg.setSection(section);

				data.setPage(pg);

				Site site = getSiteInfo(fullPath, service);

				data.setSite(site);

				ObjectMapper mapper = getObjectMapper();
				pageData = mapper.writeValueAsString(data);
			}
		} catch (Exception e) {
			LOG.error("Error processing data layer :::::::::: ", e);
		}
		return pageData;

	}

	private PageInfo createPageInfo(Page currentPage) {
		PageInfo pgInfo = new PageInfo();
		pgInfo.setPageName(currentPage.getName());
		pgInfo.setPageTemplateName(currentPage.getTemplate().getName());
		pgInfo.setPageTemplatePath(currentPage.getTemplate().getPageTypePath());

		LOG.info("CURRENT Page Name  ::: " + pgInfo.getPageName());
		LOG.info("CURRENT Page Template Name ::: " + pgInfo.getPageTemplateName());
		LOG.info("CURRENT Page Template path ::: " + pgInfo.getPageTemplatePath());

		return pgInfo;
	}

	private Content getPageContent(TagManager tm, ValueMap map, Page currentPage) {
		Content content = new Content();

		String author = map.get("pageAuthor").toString();

		author = author != null ? author : currentPage.getLastModifiedBy();
		content.setAuthor(author);

		content.setTitle(currentPage.getTitle());

		if (tm != null && map.containsKey("pageTypeTag") && tm.resolve(map.get("pageTypeTag").toString()) != null) {
			content.setType(tm.resolve(map.get("pageTypeTag").toString()).getTitle());
		}

		return content;
	}

	private Category getCategory(TagManager tm, ValueMap map) {
		Category cat = new Category();

		if (tm != null) {
			String primaryCategoryTag = map.get("primaryCategoryTag", String.class);
			if (primaryCategoryTag != null) {
				Tag primaryTag = tm.resolve(primaryCategoryTag);

				cat.setPrimaryCategory(primaryTag.getTitle());
				LOG.info("primaryTag.getTitle() ::: " + cat.getPrimaryCategory());
			}
			String[] subCategoryTag = map.get("subCategoryTag", String[].class);

			if (subCategoryTag != null) {
				Tag tg = null;

				for (int ii = 0; ii < subCategoryTag.length; ii++) {
					tg = tm.resolve(subCategoryTag[ii]);

					if (ii == 0) {
						cat.setSubCategory1(tg.getTitle());
					} else if (ii == 1) {
						cat.setSubCategory2(tg.getTitle());
					} else if (ii == 2) {
						cat.setSubCategory3(tg.getTitle());
					}
					if (ii == 2) {
						break;
					}
				}
			}
		}
		return cat;
	}

	private Section getSection(String validPath) {

		Section section = new Section();
		if (validPath != null) {
			String[] strArr = validPath.split("/");

			for (int ii = 0; ii < strArr.length; ii++) {
				if (ii == 0) {
					section.setSectionName(strArr[0]);
				} else if (ii == 1) {
					section.setSubSection1(strArr[1]);
				} else if (ii == 2) {
					section.setSubSection2(strArr[2]);
				} else if (ii == 3) {
					section.setSubSection3(strArr[3]);
				} else {
					break;
				}
			}
		}
		return section;
	}

	private Site getSiteInfo(String fullPath, SiteConfigurationService service) {

		Site site = null;
		LOG.info("SiteConfigurationService ::: " + service);
		if (service != null) {
			site = new Site();
			LOG.info("SiteConfigurationService Microsite Name ::: " + service.getMicrositeName());
			site.setName(service.getMicrositeName());
			LOG.info("SiteConfigurationService Domain::: " + service.getDomain());
			site.setDomain(service.getDomain());
			SiteConfig conf = service.getSiteConfiguration(fullPath);
			site.setSubDomain(conf.getSubDomain());
			LOG.info("SiteConfigurationService Region::: " + conf.getRegion());
			LOG.info("SiteConfigurationService Language::: " + conf.getLanguage());
			LOG.info("SiteConfigurationService Sub Domain::: " + conf.getSubDomain());

			site.setRegion(conf.getRegion() != null ? conf.getRegion().toUpperCase() : "US");
			site.setLanguage(conf.getLanguage() != null ? conf.getLanguage().toLowerCase() : "EN");

		}
		return site;
	}

	private static ObjectMapper getObjectMapper() {

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

		return mapper;
	}
}
