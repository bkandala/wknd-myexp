package com.adobe.aem.guides.wknd.core.pojo.analytics;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class Section {

	private String sectionName;

	@JsonInclude(Include.NON_NULL)
	private String subSection1;

	@JsonInclude(Include.NON_NULL)
	private String subSection2;

	@JsonInclude(Include.NON_NULL)
	private String subSection3;

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public String getSubSection1() {
		return subSection1;
	}

	public void setSubSection1(String subSection1) {
		this.subSection1 = subSection1;
	}

	public String getSubSection2() {
		return subSection2;
	}

	public void setSubSection2(String subSection2) {
		this.subSection2 = subSection2;
	}

	public String getSubSection3() {
		return subSection3;
	}

	public void setSubSection3(String subSection3) {
		this.subSection3 = subSection3;
	}

}
