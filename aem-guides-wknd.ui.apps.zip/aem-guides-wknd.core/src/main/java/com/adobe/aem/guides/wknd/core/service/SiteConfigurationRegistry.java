package com.adobe.aem.guides.wknd.core.service;

import java.util.Set;

public interface SiteConfigurationRegistry {

	public SiteConfigurationService getMicrositeConfiguration(String siteKey);

	public Set<String> getAllMicrositeConfigurationKeys();

	public SiteConfigurationService getSiteConfigByMatchingPath(String path);
}
