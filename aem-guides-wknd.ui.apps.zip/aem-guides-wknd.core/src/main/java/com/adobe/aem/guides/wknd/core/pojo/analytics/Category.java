package com.adobe.aem.guides.wknd.core.pojo.analytics;

public class Category {

	private String primaryCategory;
	private String subCategory1;
	private String subCategory2;
	private String subCategory3;

	public String getPrimaryCategory() {
		return primaryCategory;
	}

	public void setPrimaryCategory(String primaryCategory) {
		this.primaryCategory = primaryCategory;
	}

	public String getSubCategory1() {
		return subCategory1;
	}

	public void setSubCategory1(String subCategory1) {
		this.subCategory1 = subCategory1;
	}

	public String getSubCategory2() {
		return subCategory2;
	}

	public void setSubCategory2(String subCategory2) {
		this.subCategory2 = subCategory2;
	}

	public String getSubCategory3() {
		return subCategory3;
	}

	public void setSubCategory3(String subCategory3) {
		this.subCategory3 = subCategory3;
	}
}
