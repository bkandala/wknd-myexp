package com.adobe.aem.guides.wknd.core.pojo.analytics;

public class PageInfo {

	private String pageName;
	private String pageTemplateName;
	private String pageTemplatePath;

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getPageTemplateName() {
		return pageTemplateName;
	}

	public void setPageTemplateName(String pageTemplateName) {
		this.pageTemplateName = pageTemplateName;
	}

	public String getPageTemplatePath() {
		return pageTemplatePath;
	}

	public void setPageTemplatePath(String pageTemplatePath) {
		this.pageTemplatePath = pageTemplatePath;
	}
}
