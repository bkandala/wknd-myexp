package com.adobe.aem.guides.wknd.core.service.impl;

import org.apache.sling.api.request.RequestPathInfo;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.wknd.core.pojo.SiteConfig;
import com.adobe.aem.guides.wknd.core.service.DatalayerIntf;
import com.adobe.aem.guides.wknd.core.service.SiteConfigurationService;
import com.day.cq.commons.PathInfo;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;

public class DataLayerImpl implements DatalayerIntf {

	private static final Logger LOG = LoggerFactory.getLogger(DataLayerImpl.class);
	
	@Override
	public String getData(Page currentPage,
							ResourceResolver resourceResolver, SiteConfigurationService service) {
		
		String pageData = null;
		try {
			String path = currentPage.getPath();
			LOG.info("CURRENT Page Path ::: " + path);

			final RequestPathInfo mappedPathInfo = new PathInfo(resourceResolver, path);

			String fullPath = mappedPathInfo.getResourcePath();
			LOG.info("CURRENT Page FullPath ::: " + fullPath);

			if (service != null && service.isEnableDataLayer()) {
				JSONObject data = new JSONObject();

				ValueMap map = currentPage.getProperties();

				JSONObject pgInfo = createPageInfo(currentPage);

				JSONObject pg = new JSONObject();
				pg.put("pageInfo",pgInfo);

				final TagManager tm = (TagManager) resourceResolver.adaptTo(TagManager.class);

				LOG.info("TagManager TagManager ::: " + tm);
				JSONObject cont = getPageContent(tm, map, currentPage);

				pg.put("content",cont);

				JSONObject category = getCategory(tm, map);

				pg.put("category",category);

				String validPath = service.getPathForSection(fullPath);
				LOG.info("VALID PATH VALUE :: ::: " + validPath);
				JSONObject section = getSection(validPath);
				pg.put("section",section);

				data.put("page",pg);

				JSONObject site = getSiteInfo(fullPath, service);

				data.put("site",site);
				
				pageData = data.toString();
				LOG.info("pageData =====>>> "+pageData);
				
			}
		} catch (Exception e) {
			LOG.error("Error processing data layer :::::::::: ", e);
		}
		return pageData;

	}

	private JSONObject createPageInfo(Page currentPage) throws JSONException {
		JSONObject pgInfo = new JSONObject();
		pgInfo.put("pageName",currentPage.getName());
		pgInfo.put("pageTemplateName",currentPage.getTemplate().getName());
		pgInfo.put("pageTemplatePath",currentPage.getTemplate().getPageTypePath());

		LOG.info("CURRENT Page Name  ::: " + currentPage.getName());
		LOG.info("CURRENT Page Template Name ::: " + currentPage.getTemplate().getName());
		LOG.info("CURRENT Page Template path ::: " + currentPage.getTemplate().getPageTypePath());

		return pgInfo;
	}
	
	private JSONObject getPageContent(TagManager tm, ValueMap map, Page currentPage) throws JSONException {
		JSONObject content = new JSONObject();

		String author = null;
		if( map.containsKey("pageAuthor") )
		{
			author = map.get("pageAuthor").toString();
		}

		author = author != null ? author : currentPage.getLastModifiedBy();
		content.put("author",author);

		content.put("title",currentPage.getTitle());

		if (tm != null && map.containsKey("pageTypeTag") && tm.resolve(map.get("pageTypeTag").toString()) != null) {
			content.put("type",tm.resolve(map.get("pageTypeTag").toString()).getTitle());
		}

		return content;
	}
	
	private JSONObject getCategory(TagManager tm, ValueMap map) throws JSONException {
		JSONObject cat = new JSONObject();

		if (tm != null) {
			String primaryCategoryTag = map.get("primaryCategoryTag", String.class);
			if (primaryCategoryTag != null) {
				Tag primaryTag = tm.resolve(primaryCategoryTag);

				cat.put("setPrimaryCategory",primaryTag.getTitle());
				LOG.info("primaryTag.getTitle() ::: " + primaryTag.getTitle());
			}
			String[] subCategoryTag = map.get("subCategoryTag", String[].class);

			if (subCategoryTag != null) {
				Tag tg = null;

				for (int ii = 0; ii < subCategoryTag.length; ii++) {
					tg = tm.resolve(subCategoryTag[ii]);

					if (ii == 0) {
						cat.put("subCategory1",tg.getTitle());
					} else if (ii == 1) {
						cat.put("subCategory2",tg.getTitle());
					} else if (ii == 2) {
						cat.put("subCategory3",tg.getTitle());
					}
					if (ii == 2) {
						break;
					}
				}
			}
		}
		return cat;
	}
	
	private JSONObject getSection(String validPath) throws JSONException {

		JSONObject section = new JSONObject();
		if (validPath != null) {
			String[] strArr = validPath.split("/");

			for (int ii = 0; ii < strArr.length; ii++) {
				if (ii == 0) {
					section.put("sectionName",strArr[0]);
				} else if (ii == 1) {
					section.put("sectionName1",strArr[1]);
				} else if (ii == 2) {
					section.put("sectionName2",strArr[2]);
				} else if (ii == 3) {
					section.put("sectionName3",strArr[3]);
				} else {
					break;
				}
			}
		}
		return section;
	}
	
	private JSONObject getSiteInfo(String fullPath, SiteConfigurationService service) throws JSONException {

		JSONObject site = null;
		LOG.info("SiteConfigurationService ::: " + service);
		if (service != null) {
			site = new JSONObject();
			LOG.info("SiteConfigurationService Microsite Name ::: " + service.getMicrositeName());
			site.put("name",service.getMicrositeName());
			LOG.info("SiteConfigurationService Domain::: " + service.getDomain());
			site.put("domain",service.getDomain());
			SiteConfig conf = service.getSiteConfiguration(fullPath);
			site.put("subDomain",conf.getSubDomain());
			LOG.info("SiteConfigurationService Region::: " + conf.getRegion());
			LOG.info("SiteConfigurationService Language::: " + conf.getLanguage());
			LOG.info("SiteConfigurationService Sub Domain::: " + conf.getSubDomain());

			site.put("region",conf.getRegion() != null ? conf.getRegion().toLowerCase() : "us");
			site.put("language",conf.getLanguage() != null ? conf.getLanguage().toLowerCase() : "en");

		}
		return site;
	}
}
