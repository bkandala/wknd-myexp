package com.adobe.aem.guides.wknd.core.service;

import com.adobe.aem.guides.wknd.core.pojo.SiteConfig;

public interface SiteConfigurationService {

	public String getMicrositeName();

	public String getDomain();

	public String getProtocol();

	public boolean checkIfmatchingSite(String path);

	public SiteConfig getSiteConfiguration(String path);

	public String getPathForSection(String fullpath);

	public boolean isEnableDataLayer();
	
	public String getDataLayerImplClass();
}
