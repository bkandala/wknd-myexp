package com.adobe.aem.guides.wknd.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.wknd.core.service.DataLayerReflectionService;
import com.adobe.aem.guides.wknd.core.service.DataLayerService;
import com.day.cq.wcm.api.Page;

/**
 * 
 * @author CTS This class or model is responsible to calling the appropriate
 *         service classes to generate the Data Layer JSON Object.
 */
@Model(adaptables = SlingHttpServletRequest.class)
public class DatalayerModel {

	/** The logger. */
	private static final Logger LOG = LoggerFactory.getLogger(DatalayerModel.class);

	@Self
	private SlingHttpServletRequest request;

	@Inject
	Page currentPage;

	@SlingObject
	ResourceResolver resourceResolver;

	//@Inject
	//DataLayerService service;

	@Inject
	DataLayerReflectionService service;
	
	private String pageData;

	@PostConstruct
	protected void init() {

		try {
			pageData = service.getData(currentPage, resourceResolver);

		} catch (Exception e) {
			LOG.error("Error processing init method of datalayer generation.", e);
		}
	}

	public String getPageData() {
		return pageData;
	}

}
