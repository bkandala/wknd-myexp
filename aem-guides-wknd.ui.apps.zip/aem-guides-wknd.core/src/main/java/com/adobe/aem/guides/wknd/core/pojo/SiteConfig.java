package com.adobe.aem.guides.wknd.core.pojo;

public class SiteConfig {

	private String name;
	private String domain;
	private String subDomain;
	private String region;
	private String language;
	private boolean enableDataService;
	private String protocol;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getSubDomain() {
		return subDomain;
	}

	public void setSubDomain(String subDomain) {
		this.subDomain = subDomain;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public boolean isEnableDataService() {
		return enableDataService;
	}

	public void setEnableDataService(boolean enableDataService) {
		this.enableDataService = enableDataService;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
}
