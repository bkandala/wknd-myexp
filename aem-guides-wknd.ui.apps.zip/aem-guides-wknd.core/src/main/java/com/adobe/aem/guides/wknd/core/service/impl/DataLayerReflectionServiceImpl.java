package com.adobe.aem.guides.wknd.core.service.impl;

import org.apache.sling.api.request.RequestPathInfo;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.wknd.core.service.DataLayerReflectionService;
import com.adobe.aem.guides.wknd.core.service.DatalayerIntf;
import com.adobe.aem.guides.wknd.core.service.SiteConfigurationRegistry;
import com.adobe.aem.guides.wknd.core.service.SiteConfigurationService;
import com.day.cq.commons.PathInfo;
import com.day.cq.wcm.api.Page;

@Component(immediate = true, service = DataLayerReflectionService.class, configurationPid = "com.adobe.aem.guides.wknd.core.service.impl.DataLayerReflectionServiceImpl")
public class DataLayerReflectionServiceImpl implements DataLayerReflectionService {

	private static final Logger LOG = LoggerFactory.getLogger(DataLayerReflectionServiceImpl.class);
	
	@Reference
	SiteConfigurationRegistry siteService;
	
	@Override
	public String getData(Page currentPage, ResourceResolver resourceResolver) {
		String pageData = null;
		try {
			String path = currentPage.getPath();
			LOG.info("CURRENT Page Path ::: " + path);

			final RequestPathInfo mappedPathInfo = new PathInfo(resourceResolver, path);

			String fullPath = mappedPathInfo.getResourcePath();
			LOG.info("CURRENT Page FullPath ::: " + fullPath);

			SiteConfigurationService service = siteService.getSiteConfigByMatchingPath(fullPath);

			if (service != null && service.isEnableDataLayer() && service.getDataLayerImplClass() != null) {
				
				DatalayerIntf dataService = createDataLayerInstance(service.getDataLayerImplClass());
				
				if( dataService != null )
				{
					//DatalayerIntf dataService = new DataLayerOneImpl();
					pageData = dataService.getData(currentPage, resourceResolver, service);
				}
				
			}
		} catch (Exception e) {
			LOG.error("Error processing data layer :::::::::: ", e);
		}
		return pageData;
	}
	
	private DatalayerIntf createDataLayerInstance(String className)
	{
		DatalayerIntf dataService = null;
		if(className != null )
		{
			try {
				
					dataService = (DatalayerIntf) Class.forName(className).newInstance();
				
			} catch (ClassNotFoundException e) {
				LOG.error("Data layer impl class Not Found :::::::::: ", e);
			}
			catch (InstantiationException | IllegalAccessException e) {
				
				LOG.error("Error creating data layer impl class :::::::::: ", e);
			}
		}
		return dataService;
	}

}
